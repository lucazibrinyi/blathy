﻿
using Cakes;
public class testing
{
    //Definiáljon egy szavakSzama(mon) függvényt, ami a mon mondatban található szavak számát adja vissza.
    public static int szavakSzama(string mon)
    {
        if (mon == null) { return 0; }
        else
        {   List <string> list = new List <string> ();
            list = mon.Split(" ").ToList();
            return list.Count;
        }
         
    }
    //Definiáljon egy karakterSzam(ca, ch) függvényt, ami visszaadja a ch stringben előforduló ca karakterek számát.
    public static int karakterSzam(char ca, string ch)
    {
        int db=0;
        for (int i = 0; i < ch.Length; i++)
        {
            if(ca == ch[i])
            {
                db++;
            }
        }
        return db;
    }

    //Definiáljon egy inverse(ch) függvényt, ami bármilyen stringben megfordítja a karakterek sorrendjét. (Az invertált stringet fogja visszaadni a hívó programnak.)

    public static string inverse(string ch)
    {
        string inverse = "";
        for (int i = ch.Length-1; i>=0 ; i--)
        {
            inverse += ch[i];
        }
        return inverse;
    }

    //Definiáljon egy korTerulet(R) függvényt. A függvénynek egy kör területét kell visszaadni, aminek az R sugarát argumentumként adjuk meg
    public static double korTerulet(int R) => R * R * 3.14;

    //Írj függvényt, amely megadja, hogy egy adott szám hány jegyű!
    public static int hanyJegyu(int num) => num.ToString().Length;

    //Írj olyan függvényt, amelynek két paramétere van, és kiírja a paraméterek közötti páros számokat
    public static List<string> parosak(int a, int b) 
			{
        List<string> list = new List<string>();
        if (a < b)
        {
            for (int i = a+1; i < b; i++)
            {
                if (i%2==0)
                {
                    list.Add(" "+i);
                }
            }

        }
        else
        {
            for (int i = b+1; i < a; i++)
            {
                if (i % 2 == 0)
                {
                    list.Add(" "+i);
                }
            }
        }
        return list;
    }
    static void Main(string[] args)
    {
        Console.WriteLine(szavakSzama("Ez egy mondat"));
        Console.WriteLine(karakterSzam('e', "Ez egy mondat"));
        Console.WriteLine(inverse("Ez egy mondat"));
        Console.WriteLine(korTerulet(1));
        Console.WriteLine(hanyJegyu(12546));
        parosak(2, 19).ForEach(Console.Write);
        Console.WriteLine();

        Cake cake = new Cake("dobos", 2, false);
        Cake cake2 = new Cake("orosz", 1, false);
        Console.WriteLine(cake2.CakeName);
        Console.WriteLine(cake2.mennyiKaloria());
        Console.WriteLine(cake2.kremmelMegken());
        cake2.ujEmelet();
        Console.WriteLine(cake2.mennyiKaloria());
    }
}
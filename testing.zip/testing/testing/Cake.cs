﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cakes
{
    
    public class Cake
    {
        public string CakeName { get; set; }
        public int CakeLevel { get; set; }
        public bool HaveCream { get; set; }

        public Cake(string cakeName, int cakeLevel, bool haveCream)
        {
            CakeName = cakeName;
            CakeLevel = cakeLevel;
            HaveCream = haveCream;
        }

        public void ujEmelet()
        {
            CakeLevel++;
        }

        public bool kremmelMegken()
        {
            if(!HaveCream) {  HaveCream = true; return true; }
            else { return false; }
        }

        public int mennyiKaloria()
        {
            return CakeLevel*1000*(HaveCream?2:1);
        }
    }
}
